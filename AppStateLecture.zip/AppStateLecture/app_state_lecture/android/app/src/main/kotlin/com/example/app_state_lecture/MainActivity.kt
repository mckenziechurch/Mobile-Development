package com.example.app_state_lecture

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
