package com.raihanuwg.customerrest;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class TestCustomerModel {

	@BeforeAll
	static void setUpBeforeClass() throws Exception {
	}

	@AfterAll
	static void tearDownAfterClass() throws Exception {
	}

	@BeforeEach
	void setUp() throws Exception {
	}

	@AfterEach
	void tearDown() throws Exception {
	}

	@Test
	void testCustomer() {
		fail("Not yet implemented");
	}

	@Test
	void testCustomerIntStringStringStringListOfAddress() {
		fail("Not yet implemented");
	}

	@Test
	void testCustomerStringStringStringListOfAddress() {
		fail("Not yet implemented");
	}

	@Test
	void testGetFirstName() {
		fail("Not yet implemented");
	}

	@Test
	void testSetFirstName() {
		fail("Not yet implemented");
	}

	@Test
	void testGetLastName() {
		fail("Not yet implemented");
	}

	@Test
	void testSetLastName() {
		fail("Not yet implemented");
	}

	@Test
	void testGetPhoneNumber() {
		fail("Not yet implemented");
	}

	@Test
	void testSetPhoneNumber() {
		fail("Not yet implemented");
	}

	@Test
	void testGetAdressList() {
		fail("Not yet implemented");
	}

	@Test
	void testSetAdressList() {
		fail("Not yet implemented");
	}

	@Test
	void testGetId() {
		fail("Not yet implemented");
	}

	@Test
	void testSetId() {
		fail("Not yet implemented");
	}

}
