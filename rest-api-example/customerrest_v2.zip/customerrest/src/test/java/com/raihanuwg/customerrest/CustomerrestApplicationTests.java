package com.raihanuwg.customerrest;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CustomerrestApplicationTests {

	@Test
	void contextLoads() {
	}

}
