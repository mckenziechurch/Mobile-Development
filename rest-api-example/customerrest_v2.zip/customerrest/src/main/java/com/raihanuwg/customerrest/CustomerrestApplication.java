package com.raihanuwg.customerrest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CustomerrestApplication {

	public static void main(String[] args) {
		SpringApplication.run(CustomerrestApplication.class, args);
	}

}
